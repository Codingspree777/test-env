// const pg = require('pg');

// module.exports = function (data) {
//   pg.connect(uri, (err, db) => {
//     if (err) throw new Error(err);
//     db.query(tableQuery, (err, res) => {
//       if (err) {
//         console.log(err)
//       }
//     })
//   })
// }
    