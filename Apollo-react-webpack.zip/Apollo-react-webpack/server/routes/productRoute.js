// 4) connecting router to controller --- 
const express = require('express');
const router = express.Router();



  
module.exports = router;